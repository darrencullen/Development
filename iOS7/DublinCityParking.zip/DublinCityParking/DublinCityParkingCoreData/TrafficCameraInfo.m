//
//  TrafficCameraInfo.m
//  DublinCityParkingCoreData
//
//  Created by darren cullen on 11/04/2013.
//  Copyright (c) 2013 dcdevstudios. All rights reserved.
//

#import "TrafficCameraInfo.h"

@implementation TrafficCameraInfo

@dynamic name;
@dynamic url;
@dynamic code;
@dynamic postCode;
@dynamic latitude;
@dynamic longitude;
@dynamic favourite;

@end
