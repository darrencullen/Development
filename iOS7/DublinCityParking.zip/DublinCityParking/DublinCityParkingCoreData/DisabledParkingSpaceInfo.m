//
//  DisabledParkingSpaceInfo.m
//  DublinCityParking
//
//  Created by darren cullen on 08/03/2013.
//  Copyright (c) 2013 dcdevstudios. All rights reserved.
//

#import "DisabledParkingSpaceInfo.h"

@implementation DisabledParkingSpaceInfo

@dynamic street;
@dynamic spaces;
@dynamic postCode;
@dynamic latitude;
@dynamic longitude;
@dynamic favourite;

@end
