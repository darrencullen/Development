//
//  NetworkStatus.h
//  DublinCityParking
//
//  Created by darren cullen on 13/04/2013.
//  Copyright (c) 2013 dcdevstudios. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NetworkStatus : NSObject

+(BOOL)hasConnectivity;

@end
