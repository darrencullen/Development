//
//  ParkingInfoViewController.h
//  DublinCityParking
//
//  Created by darren cullen on 19/04/2013.
//  Copyright (c) 2013 dcdevstudios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ParkingInfoViewController : UITableViewController
@property (weak, nonatomic) IBOutlet UILabel *lastUpdatedLabel;

@end
