//
//  Carpark.h
//  ParsingXMLTutorial
//
//  Created by darren cullen on 24/02/2013.
//  Copyright (c) 2013 dcdevstudios. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Carpark : NSObject
@property (strong, nonatomic) NSString *name;
@property (strong, nonatomic) NSString *spaces;
@end
